""" Setup wobbleDog alembic cache with shaderKeeper 

* select alembic geo

* Force opacity on things that need it
* set share_SSS on things that need it
* set subdiv values

* Create creature_adult_alembic namespace
* put selected geo into alembic namespace
* run hookup script


"""
import maya.mel as mel
import maya.cmds as cmds
import pymel.core as pm

# Check that there's a shaderKeeper 

def setupAlembic():

    nameSpacedGeo = cmds.namespaceInfo(listOnlyNamespaces=True)
    renamedList = []
    #forces pipeline: properly named and exported creature geo:
    selected = ["body_geo", "corneas_geo", "iris_geo", "tearLine_geo", "gums_geo", "mouthMembranes_geo", "tongue_geo", "teeth_geo", "cataracts_geo", "claws_geo", "eyeWhite_geo", "eyeStaticMembrane_geo", "outerEyeMembrane_geo", "outerEyeMembrane_geoBase" ]
    for geo in selected:
        pm.setAttr( '{}Shape.aiSubdivType'.format(geo), 1 )
        pm.setAttr( '{}Shape.aiSubdivIterations'.format(geo), 3 )
        #Set opacity    
        if geo in ["corneas_geo", "iris_geo", "tearLine_geo", "gums_geo", "mouthMembranes_geo", "outerEyeMembrane_geo"]:
            print "Turning off opacity for "+ geo
            pm.setAttr( '{}Shape.aiOpaque'.format(geo), 0 )
        #Set share_SSS
        if geo in ["body_geo", "tongue_geo", "teeth_geo", "gums_geo", "mouthMembranes_geo"]:
            print "Setting share_SSS "+ geo
            pm.setAttr( '{}Shape.aiSssSetname'.format(geo), "share_SSS" )
        if geo in ["outerEyeMembrane_geoBase"]:
            print "Hiding "+ geo
            pm.setAttr( '{}.visibility'.format(geo), 0 )
    #force namespace rename
    cmds.namespace( set=':' )
    #check namespace exists
    alembicNS = cmds.namespace( exists='creature_adult_alembic' )
    if alembicNS == False:
        cmds.namespace( add='creature_adult_alembic' )
    cmds.select(selected)
    for geo in selected:
        cmds.rename( str(geo), 'creature_adult_alembic:'+str(geo) )
        renamedList.append("creature_adult_alembic:"+geo)
    selectRenamedList = cmds.select(renamedList, r=True)
    wobbleDogGroup = cmds.group(renamedList, n='wobbleDog')
    cmds.rename( 'wobbleDog', 'creature_adult_alembic:wobbleDog' ) 
    #assigns the shaders
    for x in nameSpacedGeo:
        if "shaderkeeper" in x:
            print "Found shaderkeeper"
            # Force some things. This assumes creature alembic is imported, not referenced, uses the alembicNS, shaderKeeper is referenced and nothing has been done to either:
            # PS, I'm aware this could be smarter.
            pm.select('creature_adult_alembic:body_geo')
            pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDBody_SG')
      
            pm.select('creature_adult_alembic:claws_geo')
            pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDClaws_SG')
            
            pm.select('creature_adult_alembic:tongue_geo')
            pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDTongue_SG')
            
            pm.select('creature_adult_alembic:gums_geo')
            pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDGums_SG')
            
            pm.select('creature_adult_alembic:mouthMembranes_geo')
            pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDMembranes_SG')
            
            pm.select('creature_adult_alembic:teeth_geo')
            pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDTeeth_SG')
            
            pm.select('creature_adult_alembic:outerEyeMembrane_geo')
            pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDEyeMembrane_SG')
            
            pm.select('creature_adult_alembic:tearLine_geo')
            pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDTearLine_SG')
            
            pm.select('creature_adult_alembic:eyeStaticMembrane_geo')
            pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDStaticEyeMembrane_SG')
            
            pm.select('creature_adult_alembic:iris_geo')
            pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDIris_SG')
            
            pm.select('creature_adult_alembic:corneas_geo')
            pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDCornea_SG')
            
            pm.select('creature_adult_alembic:cataracts_geo')
            pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDCataracts_SG')
            
            pm.select('creature_adult_alembic:eyeWhite_geo')
            pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDEyeWhite_SG')
        else:
            print "No shaderkeeper namespace found. Reference a creature_adult_shaderkeeper first.",
    print "Setup alembic for lighting.",

#end



"""
AllDogs hack:
select all their geos and group them, give them the creature_adult_alembic namespace and run this: 


import pymel.core as pm


pm.select('creature_adult_alembic:body_geo*')
pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDBody_SG')

pm.select('creature_adult_alembic:claws_geo*')
pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDClaws_SG')

pm.select('creature_adult_alembic:tongue_geo*')
pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDTongue_SG')

pm.select('creature_adult_alembic:gums_geo*')
pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDGums_SG')

pm.select('creature_adult_alembic:mouthMembranes_geo*')
pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDMembranes_SG')

pm.select('creature_adult_alembic:teeth_geo*')
pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDTeeth_SG')

pm.select('creature_adult_alembic:outerEyeMembrane_geo*')
pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDEyeMembrane_SG')

pm.select('creature_adult_alembic:tearLine_geo*')
pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDTearLine_SG')

pm.select('creature_adult_alembic:eyeStaticMembrane_geo*')
pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDStaticEyeMembrane_SG')

pm.select('creature_adult_alembic:iris_geo*')
pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDIris_SG')

pm.select('creature_adult_alembic:corneas_geo*')
pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDCornea_SG')

pm.select('creature_adult_alembic:cataracts_geo*')
pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDCataracts_SG')

pm.select('creature_adult_alembic:eyeWhite_geo*')
pm.hyperShade(assign = 'creature_adult_shaderkeeper:aiWDEyeWhite_SG')


"""
