""" 
Sets or reverts shaders to / from scene to shaderKeeper version.

Mel version
proc applyWDShaders()
{
sets -e -forceElement creature_adult_shaderkeeper:aiWDBody_SG creature_adult_proxy:body_geo;
sets -e -forceElement creature_adult_shaderkeeper:aiWDClaws_SG creature_adult_proxy:claws_geo;
sets -e -forceElement creature_adult_shaderkeeper:aiWDTongue_SG creature_adult_proxy:tongue_geo;
sets -e -forceElement creature_adult_shaderkeeper:aiWDGums_SG creature_adult_proxy:gums_geo;
sets -e -forceElement creature_adult_shaderkeeper:aiWDMembranes_SG creature_adult_proxy:mouthMembranes_geo;
sets -e -forceElement creature_adult_shaderkeeper:aiWDTeeth_SG creature_adult_proxy:teeth_geo;
sets -e -forceElement creature_adult_shaderkeeper:aiWDEyeMembrane_SG creature_adult_proxy:outerEyeMembrane_geo;
sets -e -forceElement creature_adult_shaderkeeper:aiWDTearLine_SG creature_adult_proxy:tearLine_geo;
sets -e -forceElement creature_adult_shaderkeeper:aiWDStaticEyeMembrane_SG creature_adult_proxy:eyeStaticMembrane_geo;
sets -e -forceElement creature_adult_shaderkeeper:aiWDIris_SG creature_adult_proxy:iris_geo;
sets -e -forceElement creature_adult_shaderkeeper:aiWDCornea_SG creature_adult_proxy:corneas_geo;
sets -e -forceElement creature_adult_shaderkeeper:aiWDCataracts_SG creature_adult_proxy:cataracts_geo;
sets -e -forceElement creature_adult_shaderkeeper:aiWDEyeWhite_SG creature_adult_proxy:eyeWhite_geo;
}
applyWDShaders();
"""

import maya.cmds as cmds
import maya.mel as mel
import pymel.core as pm

shaderKeeperNS = []
creatureNS = []
            
def setToShaderKeeper(namespaceIn):
    cmds.sets(namespaceIn+ ":body_geoShape", forceElement=shaderKeeperNS[0]+ ':aiWDBody_SG')
    cmds.sets(namespaceIn+ ":claws_geo", forceElement=shaderKeeperNS[0]+ ':aiWDClaws_SG')
    cmds.sets(namespaceIn+ ":tongue_geo", forceElement=shaderKeeperNS[0]+ ':aiWDTongue_SG')
    cmds.sets(namespaceIn+ ":gums_geo", forceElement=shaderKeeperNS[0]+ ':aiWDGums_SG')
    cmds.sets(namespaceIn+ ":mouthMembranes_geo", forceElement=shaderKeeperNS[0]+ ':aiWDMembranes_SG')
    cmds.sets(namespaceIn+ ":teeth_geo", forceElement=shaderKeeperNS[0]+ ':aiWDTeeth_SG')
    cmds.sets(namespaceIn+ ":outerEyeMembrane_geo", forceElement=shaderKeeperNS[0]+ ':aiWDEyeMembrane_SG')
    cmds.sets(namespaceIn+ ":tearLine_geo", forceElement=shaderKeeperNS[0]+ ':aiWDTearLine_SG')
    cmds.sets(namespaceIn+ ":eyeStaticMembrane_geo", forceElement=shaderKeeperNS[0]+ ':aiWDStaticEyeMembrane_SG')
    cmds.sets(namespaceIn+ ":iris_geo", forceElement=shaderKeeperNS[0]+ ':aiWDIris_SG')
    cmds.sets(namespaceIn+ ":corneas_geo", forceElement=shaderKeeperNS[0]+ ':aiWDCornea_SG')
    cmds.sets(namespaceIn+ ":cataracts_geo", forceElement=shaderKeeperNS[0]+ ':aiWDCataracts_SG')
    cmds.sets(namespaceIn+ ":eyeWhite_geo", forceElement=shaderKeeperNS[0]+ ':aiWDEyeWhite_SG')



def revertToScene(namespaceIn):
    cmds.sets(namespaceIn+ ":body_geoShape", forceElement=creatureNS[0]+ ':aiWDBody_SG')
    cmds.sets(namespaceIn+ ":claws_geo", forceElement=creatureNS[0]+ ':aiWDClaws_SG')
    cmds.sets(namespaceIn+ ":tongue_geo", forceElement=creatureNS[0]+ ':aiWDTongue_SG')
    cmds.sets(namespaceIn+ ":gums_geo", forceElement=creatureNS[0]+ ':aiWDGums_SG')
    cmds.sets(namespaceIn+ ":mouthMembranes_geo", forceElement=creatureNS[0]+ ':aiWDMembranes_SG')
    cmds.sets(namespaceIn+ ":teeth_geo", forceElement=creatureNS[0]+ ':aiWDTeeth_SG')
    cmds.sets(namespaceIn+ ":outerEyeMembrane_geo", forceElement=creatureNS[0]+ ':aiWDEyeMembrane_SG')
    cmds.sets(namespaceIn+ ":tearLine_geo", forceElement=creatureNS[0]+ ':aiWDTearLine_SG')
    cmds.sets(namespaceIn+ ":eyeStaticMembrane_geo", forceElement=creatureNS[0]+ ':aiWDStaticEyeMembrane_SG')
    cmds.sets(namespaceIn+ ":iris_geo", forceElement=creatureNS[0]+ ':aiWDIris_SG')
    cmds.sets(namespaceIn+ ":corneas_geo", forceElement=creatureNS[0]+ ':aiWDCornea_SG')
    cmds.sets(namespaceIn+ ":cataracts_geo", forceElement=creatureNS[0]+ ':aiWDCataracts_SG')
    cmds.sets(namespaceIn+ ":eyeWhite_geo", forceElement=creatureNS[0]+ ':aiWDEyeWhite_SG')    


def assignShaderkeepers():
    nameSpacedGeo = pm.namespaceInfo( listOnlyNamespaces=True )
    
    for nameSpace in nameSpacedGeo:
    
        if "creature_adult" in nameSpace and "shaderkeeper" not in nameSpace:
            creatureNS.append(nameSpace)
            #print creatureNS
            
        if "shaderkeeper" in nameSpace:
            shaderKeeperNS.append(nameSpace)
            #print shaderKeeperNS[0]    
    
    if "creature_adult" in creatureNS[0]:
                
        setShaderkeeper = cmds.confirmDialog( title='Set to shaderkeeper', message='Set shaders to shaderkeeper?', button=['Set','Revert','Cancel'], defaultButton='Set', cancelButton='Cancel', dismissString='Cancel' )
    
        if setShaderkeeper == "Set":
            for creature in creatureNS:
                setToShaderKeeper(creature)
                print "Set {}".format(str(creature))
            
    
        if setShaderkeeper == "Revert":
            for creature in creatureNS:
                setToShaderKeeper(creature)
                revertToScene(creature)
                print "Reverted {}".format(str(creature))
            
        if setShaderkeeper == "Cancel":
            print "Setup cancelled, no changes made."
    elif shaderKeeperNS == []:
        print "No shaderkeeper found."
       
    
               
#end






