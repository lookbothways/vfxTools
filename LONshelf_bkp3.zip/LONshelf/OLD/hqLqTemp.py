import maya.cmds as cmds
from LONshelf.sanityChecks import readProjectJson
reload(readProjectJson)

def start():
    # LQ / HQ sets the following values:
    AAsamples = ''
    GIDiffuseSamples = ''
    GISpecularSamples = ''
    GITransmissionSamples = ''
    GISssSamples = ''
    GIVolumeSamples = ''
    GIDiffuseDepth = ''
    GISpecularDepth = ''
    GITransmissionDepth = ''
    lowLightThreshold = ''
    
    outputQuality = cmds.confirmDialog( title='Set render quality', message='Choose settings for a HQ or LQ render...', button=['HQ','LQ','Cancel'], defaultButton='HQ', cancelButton='Cancel', dismissString='Cancel' )


    if outputQuality == "HQ":
        samples = readProjectJson.getHQsamples(AAsamples,GIDiffuseSamples,GISpecularSamples,GITransmissionSamples,GISssSamples,GIVolumeSamples,GIDiffuseDepth,GISpecularDepth,GITransmissionDepth,lowLightThreshold)
        setSamples(samples)
        
    if outputQuality == "LQ":
        samples = readProjectJson.getLQsamples(AAsamples,GIDiffuseSamples,GISpecularSamples,GITransmissionSamples,GISssSamples,GIVolumeSamples,GIDiffuseDepth,GISpecularDepth,GITransmissionDepth,lowLightThreshold)
        setSamples(samples)
        
    if outputQuality == "Cancel":
        print "No settings changed.",
    
def setSamples(samples):
    try:
        #Arnold AA settings
        cmds.setAttr('defaultArnoldRenderOptions.AASamples', samples[0])
        cmds.setAttr('defaultArnoldRenderOptions.GIDiffuseSamples', samples[1])
        cmds.setAttr('defaultArnoldRenderOptions.GISpecularSamples', samples[2])
        cmds.setAttr('defaultArnoldRenderOptions.GITransmissionSamples', samples[3])
        cmds.setAttr('defaultArnoldRenderOptions.GISssSamples', samples[4])
        cmds.setAttr('defaultArnoldRenderOptions.GIVolumeSamples', samples[5])
        cmds.setAttr('defaultArnoldRenderOptions.GIDiffuseDepth', samples[6])
        cmds.setAttr('defaultArnoldRenderOptions.GISpecularDepth', samples[7])
        cmds.setAttr('defaultArnoldRenderOptions.GITransmissionDepth', samples[8])
        
        #Low light threshold
        cmds.setAttr('defaultArnoldRenderOptions.lowLightThreshold', samples[9])
    except:
        cmds.error("setSamples failed. See script editor for details.")
        return 0    
    
