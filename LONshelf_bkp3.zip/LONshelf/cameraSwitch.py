import maya.cmds as cmds


class cameraSwitch(object):

	def __init__(self, orthographic=False):
		self.windowWidth = 400
		self.windowHeight = 70

		self.camera1Menu = ""
		self.camera2Menu = ""

		self.orthographic = orthographic 
		self.orthographicBox = ""


	def getActiveCamera(self):
		return cmds.lookThru(query=True)


	def populateCameraMenu(self, menuName):
		
		#First list all the perspective cameras
		cameraList = cmds.listCameras(perspective=True)
		for c in cameraList:
			cmds.menuItem(label=c, parent=menuName)

		if self.orthographic:
			# If indicated, list the orthographic cameras
			cameraList = cmds.listCameras(orthographic=True)
			for c in cameraList:
				cmds.menuItem(label=c, parent=menuName)


	def clearMenu(self, menuName):
		menuItems = cmds.optionMenu(menuName, query=True, itemListLong=True) # itemListLong returns the children of the menu
		if menuItems:
			cmds.deleteUI(menuItems)


	def refreshCameraMenus(self, *args):
		camera1 = cmds.optionMenu(self.camera1Menu, query=True, value=True)
		camera2 = cmds.optionMenu(self.camera2Menu, query=True, value=True)

		self.clearMenu(self.camera1Menu)
		self.clearMenu(self.camera2Menu)
		
		self.populateCameraMenu(self.camera1Menu)
		self.populateCameraMenu(self.camera2Menu)

		try:
			cmds.optionMenu(self.camera1Menu, edit=True, value=camera1)
		except:
			cmds.optionMenu(self.camera1Menu, edit=True, select=1)

		try:
			cmds.optionMenu(self.camera2Menu, edit=True, value=camera2)
		except:
			cmds.optionMenu(self.camera2Menu, edit=True, select='persp')



	def toggleOrtographic(self, *args):
		self.orthographic = not self.orthographic
		self.refreshCameraMenus()


	###

	def doSwitch(self, *args):
		camera1 = cmds.optionMenu(self.camera1Menu, query=True, value=True)
		camera2 = cmds.optionMenu(self.camera2Menu, query=True, value=True)

		activeCamera = self.getActiveCamera()
		if camera1 != activeCamera:
			cmds.lookThru(camera1)
		else:
			cmds.lookThru(camera2)


	#############################


	def main(self):

		# if UI exist delete it
		if cmds.window("cameraSwitchWindow", exists = True):
			cmds.deleteUI("cameraSwitchWindow")

		# Window
		mainWindow = cmds.window("cameraSwitchWindow", title="Camera Switch", maximizeButton=False, sizeable=True)
		mainLayout = cmds.columnLayout(w=self.windowWidth, h=self.windowHeight, rowSpacing=0, parent=mainWindow)

		cmds.text(label="")

		####

		camerasContainer = cmds.rowColumnLayout(w=self.windowWidth, numberOfColumns=3, columnWidth=[(1, 145), (2, 100), (3, 145)], columnSpacing = [(1, 2), (2, 2)], parent=mainLayout)

		self.camera1Menu = cmds.optionMenu()
		self.populateCameraMenu(self.camera1Menu)
		switchButton = cmds.button(w=50, h=30, bgc=(0.3, 0.3, 0.3), label="switch")
		self.camera2Menu = cmds.optionMenu()
		self.populateCameraMenu(self.camera2Menu)

		cmds.rowColumnLayout(w=self.windowWidth, numberOfColumns=2, columnWidth=[(1, 100), (2, 200)], columnSpacing = [(1, 2), (2, 2)], parent=mainLayout)
		cmds.text(label="")
		self.orthographicBox = cmds.checkBox(label="Include orthographic cameras", value=self.orthographic, changeCommand=self.toggleOrtographic)


		# Set default values

		# Select the active camera by default in the first menu
		activeCamera = self.getActiveCamera()
		if activeCamera != "": 
			# If the active camera is not in the menu for any reason, select the first camera in the menu
			try:
				cmds.optionMenu(self.camera1Menu, edit=True, value=activeCamera)
			except:
				cmds.optionMenu(self.camera1Menu, edit=True, select=1)
		# Select persp by default in the second menu
		cmds.optionMenu(self.camera2Menu, edit=True, value='persp')

		cmds.button(switchButton, edit=True, command=self.doSwitch)


		#####

		cmds.window("cameraSwitchWindow", edit=True, widthHeight=(self.windowWidth, self.windowHeight))

		# Refresh button popup by right clicking on the window
		cmds.popupMenu(parent="cameraSwitchWindow")
		cmds.menuItem("Refresh", command=self.refreshCameraMenus)

		# Update the camera lists when a scene is opened or a new object is createds
		cmds.scriptJob(event=["SceneOpened",self.refreshCameraMenus], parent="cameraSwitchWindow")
		cmds.scriptJob(event=["DagObjectCreated",self.refreshCameraMenus], parent="cameraSwitchWindow")

		cmds.showWindow()
