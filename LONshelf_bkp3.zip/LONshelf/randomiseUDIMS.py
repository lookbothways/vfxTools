
#randomise UDIMS per shell - used to shuffle leaves on speedtree output.

"""
Note: Currently doesn't work as planned, UDIM offset accumulates. 
Need to get around 'relative=True', move per vertex only if none of the verts are greater than the max udim offset specified.

* Get shell
* Get verts
* if any vert is greater than the max udim value, skip

OR 
Could use colorCondition on vert to randomise UDIM? 
"""
import maya.cmds as cmds
import maya.OpenMaya as om
import random

#Get selected
selected = cmds.ls(sl=True)
#get number of faces per shape
faces = cmds.polyEvaluate(selected, f=True)

#set maximum number of UDIMS
udims = 4



for i in range(faces):
    rand = random.randint(0,(udims-1))
    print "Moving shell {} to {}".format(i, rand)
    shells = cmds.polySelect( selected, extendToShell=i )
    cmds.polyEditUV( relative=True, uValue=float(rand), vValue=0.0 )
    shellNumber = cmds.polyEvaluate( shell=True )




