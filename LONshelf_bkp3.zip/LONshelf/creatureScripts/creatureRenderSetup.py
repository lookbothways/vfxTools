""" Fail is any of these can't be done """

# Force hide dynamic ribbons

# Check for creature body shader (either via shaderKeeper or directly on creatre, include raySwitch shader) - on assumption other shaders are okay if this is okay.

# Set motion-blur on for all creature geo

# Set share_SSS

# Hide those two erroneous eye geo that shouldn't render

# Fix 'froggySkin' path
