import json


def getHQsamples(project,AAsamples,GIDiffuseSamples,GISpecularSamples,GITransmissionSamples,GISssSamples,GIVolumeSamples,GIDiffuseDepth,GISpecularDepth,GITransmissionDepth,lowLightThreshold):
    print project
    with open("/mnt/projects/library/arnoldSettings/presets/wb.json") as json_file:
        data = json.load(json_file)
        for p in data['HQsamples']:
            AAsamples = int((p['AASamples']))
            GIDiffuseSamples = int((p['GIDiffuseSamples']))
            GISpecularSamples = int((p['GISpecularSamples']))
            GITransmissionSamples = int((p['GITransmissionSamples']))
            GIVolumeSamples = int((p['GIVolumeSamples']))
            GIDiffuseDepth = int((p['GIDiffuseDepth']))
            GISpecularDepth = int((p['GISpecularDepth']))
            GITransmissionDepth = int((p['GITransmissionDepth']))
            GISssSamples = int((p['GISssSamples']))
            lowLightThreshold = float((p['lowLightThreshold']))
            output = 'LQ Samples: '+ str(AAsamples)+ str(GIDiffuseSamples)+ str(GISpecularSamples)+ str(GITransmissionSamples)+ str(GIVolumeSamples)+ ' Diffuse depth: '+ str(GIDiffuseDepth)+ ' Spec Depth '+ str(GISpecularDepth)+ ' Light threshold '+ str(lowLightThreshold)
            return(AAsamples,GIDiffuseSamples,GISpecularSamples,GITransmissionSamples,GISssSamples,GIVolumeSamples,GIDiffuseDepth,GISpecularDepth,GITransmissionDepth,lowLightThreshold)
              

def getLQsamples(project,AAsamples,GIDiffuseSamples,GISpecularSamples,GITransmissionSamples,GISssSamples,GIVolumeSamples,GIDiffuseDepth,GISpecularDepth,GITransmissionDepth,lowLightThreshold):

    with open("/mnt/projects/library/arnoldSettings/presets/{}.json".format(project)) as json_file:
        data = json.load(json_file)
        for p in data['LQsamples']:
            AAsamples = int((p['AASamples']))
            GIDiffuseSamples = int((p['GIDiffuseSamples']))
            GISpecularSamples = int((p['GISpecularSamples']))
            GITransmissionSamples = int((p['GITransmissionSamples']))
            GIVolumeSamples = int((p['GIVolumeSamples']))
            GIDiffuseDepth = int((p['GIDiffuseDepth']))
            GISpecularDepth = int((p['GISpecularDepth']))
            GITransmissionDepth = int((p['GITransmissionDepth']))
            GISssSamples = int((p['GISssSamples']))
            lowLightThreshold = float((p['lowLightThreshold']))
            output = 'LQ Samples: '+ str(AAsamples)+ str(GIDiffuseSamples)+ str(GISpecularSamples)+ str(GITransmissionSamples)+ str(GIVolumeSamples)+ ' Diffuse depth: '+ str(GIDiffuseDepth)+ ' Spec Depth '+ str(GISpecularDepth)+ ' Light threshold '+ str(lowLightThreshold)
            return(AAsamples,GIDiffuseSamples,GISpecularSamples,GITransmissionSamples,GISssSamples,GIVolumeSamples,GIDiffuseDepth,GISpecularDepth,GITransmissionDepth,lowLightThreshold)
              


"""
#To do:
#SG get project name
#write project name.json

# Use this to write the project file:

data = {}  
data['projectName'] = [] 
data['projectName'].append({  
    'projectName': 'wb', 
})

data['arnoldSettingsRenderGlobals'] = [] 
data['arnoldSettingsRenderGlobals'].append({  
    'arnoldSettingsRenderGlobals': '/mnt/projects/library/arnoldSettings/presets/atk_arnoldSettings_v004.json', 
})


data['HQsamples'] = []  
data['HQsamples'].append({  
    'AASamples': '8',
    'GIDiffuseSamples': '5',
    'GISpecularSamples': '5',
    'GITransmissionSamples': '5',
    'GISssSamples': '5',
    'GIVolumeSamples': '5',
    'GIDiffuseDepth': '1',
    'GISpecularDepth': '1',
    'GITransmissionDepth': '4',
    'lowLightThreshold': '0.015',
})

data['LQsamples'] = []  
data['LQsamples'].append({  
    'AASamples': '2',
    'GIDiffuseSamples': '2',
    'GISpecularSamples': '2',
    'GITransmissionSamples': '2',
    'GISssSamples': '2',
    'GIVolumeSamples': '2',
    'GIDiffuseDepth': '0',
    'GISpecularDepth': '1',
    'GITransmissionDepth': '2',
    'lowLightThreshold': '0.015',
})

data['defaultLightRigPath'] = [] 
data['defaultLightRigPath'].append({  
    'lightRigPath': '/mnt/projects/library/arnoldSettings/scenes/atk_defaultLights_v001.ma', 
})

with open('/mnt/projects/library/arnoldSettings/presets/wb.json', 'w') as outfile:  
    json.dump(data, outfile)
    
    
"""
    

