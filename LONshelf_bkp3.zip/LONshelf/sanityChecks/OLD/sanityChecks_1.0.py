
import maya.cmds as cmds
import maya.mel as mel
import sys
import pymel.core
import os
import time 

#ATK sanitychecks

#Add file path metaData
#Hide assistants
#Set project here
#hide all imagePlanes
#Sets up distortion ST maps connections

def addAlembicMetaData():
    
    import maya.cmds as cmds

    # Determine the alembic filepath
    abcList = cmds.ls("*AlembicNode")
    for x in abcList:
        if "_ANM_" in x:
            nodeName = str(x)
            
    if nodeName > 1:
        print "Warning: More than one alembic animation found!",
            
    alembicFilePath = nodeName[:-12] + ".abc"
    print "To be added to the metadata: " + alembicFilePath,
    
    nodeName = "defaultArnoldDriver.customAttributes"
    filePath = cmds.file(q=1,sn=1)
    alembicFile = {"type":"STRING","name":"alembicFile","value": alembicFilePath}
       
    def addAttribute(nodeName, value): # If the attribute doesn't exist already
        nextIndex = 0
        if cmds.getAttr(nodeName, multiIndices= True):
            nextIndex = cmds.getAttr(nodeName, multiIndices= True)[-1] + 1
        cmds.setAttr(nodeName + '[' + str(nextIndex) + ']', "%s %s %s" % (value["type"],value["name"],value["value"]), type="string")
    
    def changeAttribute(nodename, value): # If the attribute already exists
        for nodeNameIndex,i in enumerate(pymel.core.getAttr(nodeName)):
            j= i.split(" ")
            if len(j)>1:
                if j[1] == 'alembicFile':
                    cmds.setAttr(nodeName + '[' + str(nodeNameIndex) + ']', "%s %s %s" % (value["type"],value["name"],value["value"]), type="string")
                    break
    
    attributes=[]
    for i in pymel.core.getAttr(nodeName):
        j= i.split(" ")
        if len(j)>1:
            attributes.append(j[1])
                
    if "alembicFile" in attributes: # If the attribute already exists
        metaDataAction = "alembicFile attribute existed, overwrote with new filename."
        changeAttribute(nodeName,alembicFile)
                   
    else: # The attribute doesn't exist already
        metaDataAction = "mayaFile attribute did not exist. Added it for you."
        addAttribute(nodeName,alembicFile)
     
    print metaDataAction,


def addFilePathMetaData():
    
    # Adds metaData of saved name to the mayaFile metaData slot 
    nodeName = "defaultArnoldDriver.customAttributes"
    filePath = cmds.file(q=1,sn=1)
    mayaFile = {"type":"STRING","name":"mayaFile","value": filePath}
    
    def addAttribute(nodeName, value):
        #add an attribute
        nextIndex = 0
        if cmds.getAttr(nodeName, multiIndices= True):
            nextIndex = cmds.getAttr(nodeName, multiIndices= True)[-1] + 1
        cmds.setAttr(nodeName+'['+str(nextIndex)+']', "%s %s %s" % (value["type"],value["name"],value["value"]), type="string")
    
    def changeAttribute(nodename, value):
        for nodeNameIndex,i in enumerate(pymel.core.getAttr(nodeName)):
            j= i.split(" ")
            if len(j)>1:
                if j[1] == 'mayaFile':
                    cmds.setAttr(nodeName+'['+str(nodeNameIndex)+']', "%s %s %s" % (value["type"],value["name"],value["value"]), type="string")
                    break
    
    attributes=[]
    for i in pymel.core.getAttr(nodeName):
        j= i.split(" ")
        if len(j)>1:
            attributes.append( j[1])    
        
    if "mayaFile" in attributes:
        metaDataAction = "mayaFile attribute existed, overwrote with new filename."
        #change the attribute
        changeAttribute(nodeName,mayaFile)
              
    else:
        #add an attribute
        metaDataAction = "mayaFile attribute did not exist. Added it for you."
        addAttribute(nodeName,mayaFile)
     
    print "Added metaData"
    #sys.stdout.write("metaData status: %s\n" %metaDataAction)


#Hide Assistants 					New version below - TS 3/4/18
#def hideAssistants():
#    renderlayers = cmds.ls(type="renderLayer")
#    print renderlayers
#    
#    if u'default_light_rig:defaultRenderLayer' in renderlayers:  
#        renderlayers.remove(u'default_light_rig:defaultRenderLayer')
#        print renderlayers
#    
#    for layer in renderlayers:
#        print layer
#        #select the render layer
#        cmds.editRenderLayerGlobals(crl=layer)
#        #wordIn = "Assistants"
#        sel = cmds.ls("::Assistants::", r=True)
#        cmds.select(sel)
#        cmds.hide(sel)
#    print "Hid Assistants"

def hideAssistants():
    findAssistants = cmds.ls("::Assistants", r=True)
    try:
        if findAssistants:
            cmds.select(findAssistants)
            cmds.hide(findAssistants)
            print "PRC-HideAssistants: Completed",
            return 1
        else:
            print "PRC-HideAssistants: No Assistants Found!",
            return 1
    except:
        print "PRC-HideAssistants: Error!",
        return 0 


def setProjectHere():
    #set project here

    scene = cmds.file(q=1,sn=1)
    project = os.path.dirname(os.path.dirname(scene))
    mel.eval('setProject("%s")' % project)
    sys.stdout.write("Project location set: %s" %project)


def delAllImagePlanes():

    renderlayers = cmds.ls(type="renderLayer")
    print renderlayers
    
    if u'default_light_rig:defaultRenderLayer' in renderlayers:  
        renderlayers.remove(u'default_light_rig:defaultRenderLayer')
        print renderlayers
        
    #deletes all camera relatives
    #allCameras = cmds.ls(type=['camera'])
    #imagePlanes = str(mel.eval('ls -typ "imagePlane"'))
    #print "imagePlanes: "+ imagePlanes
    #hasrelatives = []  ## Hidden because this deletes imageplanes instead of setting their display mode to None - Toby 5/3/18
    #for cam in allCameras:
    #    if cmds.listRelatives(cam):
    #        hasrelatives = cmds.listRelatives(cam)
    #        print "Deleted "+ str(hasrelatives)[3:-2]
    #        cmds.delete(hasrelatives)
    #        imagePlanes = str(mel.eval('ls -typ "imagePlane"'))

    imageplanes = cmds.ls(type="imagePlane")
    for imgpln in imageplanes:
        try:
            command = imgpln + ".displayMode"
            cmds.setAttr(command, 0)
            print "Image Plane Display Mode set to None: ", imgpln
            
        except:
            from maya import OpenMaya
            OpenMaya.MGlobal.displayError("Error: one of the Image Planes couldn't be hidden!")
            
    
    
#deletedplanes = []
#deleteAllImagePlanes()

def checkRenderCamera():

    # pick up here - check this is working
    myCameras=cmds.ls(typ='camera',l=True)
    renderableList=[]

    for x in myCameras:
        if cmds.getAttr(x+'.renderable'):
            renderableList.append(x)

    ll=len(renderableList)

    if ll==0 or ll>=5:
        print('There are more than 4, or no renderable cameras in the scene')
        return 0
    return 1

def renderSettingsAlwaysOn():
    cmds.setAttr( 'defaultArnoldDriver.autocrop', 1)
    cmds.setAttr( 'defaultArnoldRenderOptions.bucketScanning', 2)
    cmds.setAttr( 'defaultArnoldRenderOptions.bucketSize', 32) 
    cmds.setAttr( 'defaultArnoldRenderOptions.abortOnLicenseFail', 1)
    cmds.setAttr ("defaultRenderGlobals.currentRenderer", "arnold", type="string")
    cmds.setAttr ("defaultRenderGlobals.outFormatControl", 0)
    cmds.setAttr ("defaultRenderGlobals.animation", 1)
    cmds.setAttr ("defaultRenderGlobals.putFrameBeforeExt", 1)
    cmds.setAttr ("defaultRenderGlobals.extensionPadding", 4)
    cmds.setAttr ("defaultRenderGlobals.periodInExt", 1)  

"""
For shelf:
from sanityChecks import sanityChecks

reload(sanityChecks)
sanityChecks.renderSettingsAlwaysOn()

outputQuality = cmds.confirmDialog( title='Set render quality', message='HQ: 84440 subdiv 4\nLQ: 211110 subdiv 1', button=['HQ','LQ','Cancel'], defaultButton='HQ', cancelButton='Cancel', dismissString='Cancel' )

if outputQuality == "HQ":
    sanityChecks.setHQ()
    print "Set HQ samples 844440, turned on Subdiv + Disp. Subdiv max = 3",

if outputQuality == "LQ":
    sanityChecks.setLQ()
    print "Set LQ samples 211110, Subdiv max = 1",

if outputQuality == "Cancel":
    print "No settings changed.",
""" 
def setHQ():
    #Turn on Disp + Subviv, blur
    cmds.setAttr( 'defaultArnoldRenderOptions.maxSubdivisions', 3)
    cmds.setAttr( 'defaultArnoldRenderOptions.ignoreSubdivision', 0)
    cmds.setAttr( 'defaultArnoldRenderOptions.ignoreDisplacement', 0)        
    cmds.setAttr( 'defaultArnoldRenderOptions.motion_blur_enable', 1)
    cmds.setAttr( 'defaultArnoldRenderOptions.ignoreBump', 0)
    
    #Arnold AA settings
    cmds.setAttr( 'defaultArnoldRenderOptions.AASamples', 8 )
    cmds.setAttr( 'defaultArnoldRenderOptions.GIDiffuseSamples', 4 )
    cmds.setAttr( 'defaultArnoldRenderOptions.GISpecularSamples', 4 )
    cmds.setAttr( 'defaultArnoldRenderOptions.GITransmissionSamples', 4 )
    cmds.setAttr( 'defaultArnoldRenderOptions.GISssSamples', 4 )    
    cmds.setAttr( 'defaultArnoldRenderOptions.GIVolumeSamples', 0 )    
    #cmds.setAttr( 'defaultArnoldRenderOptions.GIDiffuseDepth', 0 )
    cmds.setAttr( 'defaultArnoldRenderOptions.GISpecularDepth', 1 )
    cmds.setAttr( 'defaultArnoldRenderOptions.GITransmissionDepth', 4 )        

    #Low light threshold
    cmds.setAttr( 'defaultArnoldRenderOptions.lowLightThreshold', 0.015 )

def setLQ():
    #Turn on Disp + Subviv, blur
    cmds.setAttr( 'defaultArnoldRenderOptions.maxSubdivisions', 1)
    cmds.setAttr( 'defaultArnoldRenderOptions.motion_blur_enable', 1)
    cmds.setAttr( 'defaultArnoldRenderOptions.ignoreBump', 0)
    
    #Arnold AA settings
    cmds.setAttr( 'defaultArnoldRenderOptions.AASamples', 2 )
    cmds.setAttr( 'defaultArnoldRenderOptions.GIDiffuseSamples', 1 )
    cmds.setAttr( 'defaultArnoldRenderOptions.GISpecularSamples', 1 )
    cmds.setAttr( 'defaultArnoldRenderOptions.GITransmissionSamples', 1 )
    cmds.setAttr( 'defaultArnoldRenderOptions.GISssSamples', 1 )    
    cmds.setAttr( 'defaultArnoldRenderOptions.GIVolumeSamples', 0 )    
    #cmds.setAttr( 'defaultArnoldRenderOptions.GIDiffuseDepth', 0 )
    cmds.setAttr( 'defaultArnoldRenderOptions.GISpecularDepth', 1 )
    cmds.setAttr( 'defaultArnoldRenderOptions.GITransmissionDepth', 4 )        

    #Low light threshold
    cmds.setAttr( 'defaultArnoldRenderOptions.lowLightThreshold', 0.015 )

#-------------------------------------------------------------------------------

def executeThis():
    renderSettingsAlwaysOn()

    #checks to see if distortion file exists:
    distortionExists=False
    matching = []
        
    fileNodes=cmds.ls(typ='aiImage')
    matching = [s for s in fileNodes if "UV_lensDistortionMap" in s]
    
    if matching:
        print "Lens Distortion UV_lensDistortionMap aiImage exists."
        distortionExists=False
    else:
        print "Lens distortion UV_lensDistortionMap aiImage does not exist"


    #Creates a dialogue with checkboxes for the above defs
    
    if not checkRenderCamera():
        cmds.error('Please pick a camera to render')

    class createMyLayoutCls(object):
        def __init__(self, *args):
            pass

        def show(self):
            self.createMyLayout()

        def createMyLayout(self):

            #check to see if our window exists
            if cmds.window('utility', exists = True):
                cmds.deleteUI('utility')

            # create window
            self.window = cmds.window('utility', widthHeight = (200, 220), title = 'Pre-render checks', resizeToFitChildren=1, sizeable = True)

            cmds.setParent(menu=True)

            # create a main layout
            mainLayout = cmds.columnLayout(w = 200, h = 200, cw = 10, rs = 8, co = ['both',2])

            # Control - which things to do
            
            self.AFPMDbox = cmds.checkBox('Add Filepath MetaData', value=True)
            #self.setProjectbox = cmds.checkBox('Set Project Here', value=True)
            self.deleteAllImagePlanesbox = cmds.checkBox('Disable Image Planes', value=True)
            self.hideAssbox = cmds.checkBox('Hide Assistants', value=True)
            self.distortion = cmds.checkBox('Setup Distortion', value=distortionExists)
            self.hqRender = cmds.checkBox('HQ Render', value=False)

            # Buttons that do things
            btnDoSelected = cmds.button(label = 'Do Selected', width = 200, height = 40, c = self.GetSelectedNodes)
            btnNoChanges = cmds.button(label = 'Make no changes', width = 200, height = 40, c = self.noChangesMade)
            
           
            # show window
            cmds.showWindow(self.window)

        def GetSelectedNodes(self,*args):
                
            hideAss = cmds.checkBox(self.hideAssbox,q = True, v = True)
            AFPMD = cmds.checkBox(self.AFPMDbox,q = True, v = True)
            #setProject = cmds.checkBox(self.setProjectbox,q = True, v = True)
            deleteAllImagePlanes = cmds.checkBox(self.deleteAllImagePlanesbox,q = True, v = True)
            distortion = cmds.checkBox(self.distortion,q = True, v = True)
            hqRenderSettings = cmds.checkBox(self.hqRender,q = True, v = True)
            
            print hideAss
            if hideAss == True:
                hideAssistants()
                
            print AFPMD
            if AFPMD == True:
                addFilePathMetaData()
                
            print deleteAllImagePlanes
            if deleteAllImagePlanes == True:
                delAllImagePlanes()

            #print setProject
            #if setProject == True:
            #    setProjectHere()
                
            print distortion
            if distortion == True:
                import setupMayaLensDistortionOptions
                reload(setupMayaLensDistortionOptions)
                setupMayaLensDistortionOptions.doSomething()

            print hqRenderSettings
            if hqRenderSettings == True:
                renderSettingsAlwaysOn()
                setHQ()

            if cmds.window('utility', exists = True):
                cmds.deleteUI('utility')
            
            
            mel.eval('SubmitJobToDeadline')
        
        
               
        def noChangesMade(self,*args):
            cmds.deleteUI('utility')
            
            mel.eval('SubmitJobToDeadline')
            print "No changes made, proceeding to Deadline Submission."

  

    b_cls = createMyLayoutCls()  
    b_cls.show()






#end




